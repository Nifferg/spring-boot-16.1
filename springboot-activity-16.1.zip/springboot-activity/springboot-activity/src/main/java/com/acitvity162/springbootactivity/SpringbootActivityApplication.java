package com.acitvity162.springbootactivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootActivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootActivityApplication.class, args);
	}

}
