package com.acitvity162.springbootactivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootActivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
